package com.dicoding.githubuserapp

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.dicoding.githubuserapp.databinding.ActivityDetailBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity() {
    private var dataGithub : ItemsItem? = null

    companion object {
        const val ITEM_USER = "item_user"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
    }
    private lateinit var binding: ActivityDetailBinding

    private val detailViewModel by viewModels<DetailViewModel>()

    private fun setData() {
        Glide.with(this)
            .load(dataGithub!!.avatarUrl)
            .circleCrop()
            .into(binding.detailActivity.detailAvatar)

        binding.detailActivity.apply {
            detailUsername.text = dataGithub!!.login
            detailRepository.text = dataGithub!!.publicRepos.toString()
            detailFollowers.text = dataGithub!!.followers.toString()
            detailFollowing.text = dataGithub!!.following.toString()
            detailCompany.text = dataGithub!!.company.toString()
            detailLocation.text = dataGithub!!.location.toString()
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val data = intent.getParcelableExtra<ItemsItem>(ITEM_USER)
        val sectionsPagerAdapter = SectionsPagerAdapter(this)
        val uname = data!!.login

        if (uname != null) {
            detailViewModel.infoDetailUser(uname)
            sectionsPagerAdapter.unameAdapter = uname
        }

        detailViewModel.listDetail.observe(this) { user ->
            dataGithub = user
            setData()
        }

        detailViewModel.isLoading.observe(this) { loadingState ->
            setState(loadingState)
        }

        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        viewPager.adapter = sectionsPagerAdapter
        val tabs: TabLayout = findViewById(R.id.tabs)
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()
        supportActionBar?.elevation = 0f

        Log.d("DetailDebugger", data.toString())
    }

    private fun setState(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.INVISIBLE
        binding.detailActivity.root.visibility = if (isLoading) View.INVISIBLE else View.VISIBLE
    }
}

