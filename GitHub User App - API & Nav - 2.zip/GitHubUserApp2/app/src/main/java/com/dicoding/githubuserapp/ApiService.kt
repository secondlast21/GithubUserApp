package com.dicoding.githubuserapp

import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("search/users")
    fun getUser(
        @Query("q") string: String
    ): Call<UserResponse>

    @GET("users/{username}")
    fun detailUser (
        @Path(value = "username") string: String
    ): Call<ItemsItem>

    @GET("users/{username}/followers")
    fun followersUser (
        @Path(value = "username") string: String
    ): Call<List<ItemsItem>>

    @GET("users/{username}/following")
    fun followingUser (
        @Path(value = "username") string: String
    ): Call<List<ItemsItem>>
}